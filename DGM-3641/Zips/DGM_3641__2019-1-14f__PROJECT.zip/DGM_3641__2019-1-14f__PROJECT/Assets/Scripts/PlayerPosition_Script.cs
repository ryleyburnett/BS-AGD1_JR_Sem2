﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerPosition_Script : MonoBehaviour
{
    public Vector3 objPosition;
    public DataSO_Script data;
    
    void Start()
    {
        
    }

    void Update()
    {
        objPosition = gameObject.transform.position;
        data.playerPosition = objPosition;
    }
}
