﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu(fileName = "Data_SO_Script", menuName = "Data_SO_Script")]
public class DataSO_Script : ScriptableObject
{
    public Vector3 playerPosition;
    public Vector3 targetPosition;

}
