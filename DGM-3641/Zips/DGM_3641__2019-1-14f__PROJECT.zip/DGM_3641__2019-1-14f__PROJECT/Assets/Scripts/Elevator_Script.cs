﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Elevator_Script : MonoBehaviour
{
    public bool isTriggered;
    public float elevatorSpeed = 0.5f;
    
    void Start()
    {
        isTriggered = false;
    }

    private void OnTriggerEnter(Collider other)
    {
        print("Triggered");
        isTriggered = true;
    }
    
    void Update()
    {
        if (isTriggered)
        {
            transform.Translate(Vector3.down * (Time.deltaTime * elevatorSpeed), Space.World);
        }
    }
}
