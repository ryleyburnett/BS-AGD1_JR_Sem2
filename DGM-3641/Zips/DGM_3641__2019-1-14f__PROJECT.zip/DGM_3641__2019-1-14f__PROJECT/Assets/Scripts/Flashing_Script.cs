﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Flashing_Script : MonoBehaviour
{
    public DataSO_Script data;
    public GameObject targetObj;
    public float proximityX;
    public float proximityZ;

    void Start()
    {
        data.targetPosition = targetObj.transform.position;
    }

    void Update()
    {
        proximityX = (data.targetPosition.x - data.playerPosition.x);
        proximityZ = (data.targetPosition.z - data.playerPosition.z);
        
    }
}
